import os
import pytz
import datetime
import schedule
import time
from dotenv import load_dotenv
from firebase_admin import credentials, firestore, initialize_app
from twilio.rest import Client
from prayer_times import get_prayer_times
from twilio.rest import Client
load_dotenv()
twilio_account_sid = os.getenv('TWILIO_ACCOUNT_SID')
twilio_auth_token = os.getenv('TWILIO_AUTH_TOKEN')
twilio_phone_number = os.getenv('TWILIO_PHONE_NUMBER')
firebase_credentials = os.getenv('GOOGLE_APPLICATION_CREDENTIALS')

cred = credentials.Certificate(firebase_credentials)
initialize_app(cred)

db = firestore.client()
client = Client(twilio_account_sid, twilio_auth_token)


def add_user(phone_number, zipcode):
    user_ref = db.collection('users').document(phone_number)
    user_ref.set({'phone_number': phone_number, 'zipcode': zipcode})

    # Send a confirmation SMS
    send_confirmation_sms(phone_number)

    print(f"User {phone_number} added")


def send_confirmation_sms(phone_number):
    confirmation_message = "You have successfully subscribed to Athan reminders. Reply with 'STOP' to unsubscribe."
    twilio_client.messages.create(
        body=confirmation_message,
        from_=twilio_phone_number,
        to=phone_number
    )


def send_prayer_reminders():
    users_ref = db.collection('users')
    users = users_ref.stream()

    for user in users:
        phone_number = user.id
        zipcode = user.to_dict()['zipcode']
        prayer_times = get_prayer_times(zipcode)

        for prayer_name, prayer_time in prayer_times.items():
            local_time = datetime.datetime.strptime(prayer_time, '%H:%M')
            tz = pytz.timezone('US/Pacific')  # Adjust the timezone accordingly
            local_time = tz.localize(local_time)

            if is_time_to_send_reminder(local_time):
                send_sms(
                    phone_number, f"It's time for {prayer_name} prayer at {prayer_time}")


def is_time_to_send_reminder(prayer_time):
    now = datetime.datetime.now(pytz.utc)
    time_difference = (now - prayer_time).total_seconds()
    return 0 <= time_difference <= 60  # Send reminder if it's within 1 minute


def send_sms(to_phone_number, message):
    client.messages.create(
        to=to_phone_number,
        from_=twilio_phone_number,
        body=message
    )
    print(f"Sent SMS to {to_phone_number}: {message}")


def remove_user(phone_number):
    user_ref = db.collection('users').document(phone_number)
    user_ref.delete()
    print(f"User {phone_number} removed")


def main():
    print("Athan Reminder App\n")

    schedule.every(1).minutes.do(send_prayer_reminders)

    while True:
        print("Options:")
        print("1. Add user")
        print("2. Remove user")
        print("3. Run reminder service manually")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            phone_number = input("Enter the phone number (E.g. +1234567890): ")
            zipcode = input("Enter the zipcode: ")
            add_user(phone_number, zipcode)
        elif choice == '2':
            phone_number = input(
                "Enter the phone number to remove (E.g. +1234567890): ")
            remove_user(phone_number)
        elif choice == '3':
            send_prayer_reminders()
        elif choice == '4':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

        # Run the scheduled tasks
        schedule.run_pending()
        time.sleep(1)


if __name__ == "__main__":
    main()
