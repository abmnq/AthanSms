import requests
from datetime import datetime


def get_prayer_times(zipcode):
    url = f'http://api.aladhan.com/v1/timingsByAddress?address={zipcode}&method=2'
    response = requests.get(url)
    data = response.json()

    if data['status'] == 'OK':
        prayer_data = data['data']['timings']

        prayer_times = {
            'Fajr': prayer_data['Fajr'],
            'Dhuhr': prayer_data['Dhuhr'],
            'Asr': prayer_data['Asr'],
            'Maghrib': prayer_data['Maghrib'],
            'Isha': prayer_data['Isha']
        }

        return prayer_times
    else:
        print(
            f"Error fetching prayer times for zipcode {zipcode}: {data['message']}")
        return None
