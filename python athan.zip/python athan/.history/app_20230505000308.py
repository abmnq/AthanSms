from flask import Flask, render_template, request, redirect, url_for
import athan

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        phone_number = request.form['phone_number']
        zipcode = request.form['zipcode']
        athan.add_user(phone_number, zipcode)
        return redirect(url_for('success'))
    return render_template('index.html')


@app.route('/success')
def success():
    return render_template('success.html')


if __name__ == '__main__':
    app.run(debug=True)
